from django.apps import AppConfig


class LearningPythonConfig(AppConfig):
    name = 'learning_python'
